This directory is sanitized for public GitHub sharing.

Changes from original bundle:
1) predictions.first500.submit.jsonl: removed field model_name_or_path from every JSONL record.
2) sources.first500.tsv: source_file column is redacted to "REDACTED".
3) summary.txt and missing_instances.txt are unchanged in content.

Generated on: 2026-04-02
